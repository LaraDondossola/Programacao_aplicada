#include <iostream>

using namespace std;

int main(){
	float n1, n2;
	
	cout << "Digite o primeiro numero: " << endl;
	cin >> n1; 
	cout << "Digite o segundo numero: " << endl;
	cin >> n2;
	
	if (n1>n2){
		cout << "O maior numero e: " << n1;
	}
	
	if (n2>n1){
		cout << "O maior numero e: " << n2;
	}
	
	else{
		cout <<"Os numeros sao iguais.";
	}
	
	return 0;
}

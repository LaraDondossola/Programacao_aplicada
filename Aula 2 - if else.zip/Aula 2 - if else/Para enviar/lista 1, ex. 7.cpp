#include <iostream>
#include <string>

using namespace std;

int main(){
	float h;
	char x;
	
	cout << "Digite sua altura: " << endl;
	cin >> h;
	cout << "Digite M para masculino e F para feminino: " << endl;
	cin >> x;
	x = toupper(x);
	
	if (x == 'M'){
		cout << "O seu peso ideal e : " << (72.7*h)-58 <<"kg.";
	}
	
	if (x == 'F'){
		cout << "O seu peso ideal e : " << (62.1*h)-44.7 <<"kg.";
	}
	
	return 0;
}

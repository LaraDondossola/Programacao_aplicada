#include <iostream>

using namespace std;

int main(){
	float salario;
	
	cout << "Digite seu salario: " << endl;
	cin >> salario;
	
	if (salario <= 280){
		cout << "Seu salario era: " << salario << endl;
		cout << "Percentual aplicado: 20% " << endl;
		cout << "Seu salario aumentou: " << salario*0.2 << endl;
		cout << "Seu novo salario: " << salario*1.2 << endl;
	}
	
	if (salario > 280 && salario <= 700){
		cout << "Seu salario era: " << salario << endl;
		cout << "Percentual aplicado: 15% " << endl;
		cout << "Seu salario aumentou: " << salario*0.15 << endl; 
		cout << "Seu novo salario: " << salario*1.15<< endl;
	} 
	
	if (salario > 700 && salario <= 1500){
		cout << "Seu salario era: " << salario<< endl;
		cout << "Percentual aplicado: 10% " << endl;
		cout << "Seu salario aumentou: " << salario*0.1 << endl;
		cout << "Seu novo salario: " << salario*1.1<< endl;
	}
	
		if (salario > 1500){
		cout << "Seu salario era: " << salario<< endl;
		cout << "Percentual aplicado: 5% " << endl;
		cout << "Seu salario aumentou: " << salario*0.05<< endl;
		cout << "Seu novo salario: " << salario*1.05<< endl;
	}
	
	return 0;
}

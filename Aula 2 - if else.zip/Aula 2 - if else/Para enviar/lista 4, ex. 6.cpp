#include <iostream>

using namespace std;

int main(){
	
	cout << "Os numeros impares de 1 ate 50 sao: " << endl;
	
	for (int i = 0; i <= 50; ++i){
		if ((i%2) != 0){
			cout << i << endl;
		}
	}
	return 0;
}

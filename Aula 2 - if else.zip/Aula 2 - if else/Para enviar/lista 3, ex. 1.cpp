#include <iostream>

using namespace std;

int main(){
	int x;
	
	cout << "Digite um numero de 0 at� 15 para mostrar sua classificacao: ";
	cin >> x;
	
	switch(x){
		case 1:
		cout << "Alimento nao-perecivel.";
		break;
		
		case 2 ... 4:
		cout << "Alimento perecivel.";
		break;
		
		case 5 ... 6:
		cout << "Vestuario.";
		break;
		
		case 7:
		cout << "Higiene pessoal.";
		break;
		
		case 8 ... 15:
		cout << "Limpeza e Utensilios Domesticos.";
		break;
		
		
		default: 
		cout << "Numero invalido!";
		break;	
	}
	return 0;
}

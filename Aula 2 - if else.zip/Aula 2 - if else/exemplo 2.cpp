#include <iostream>

using namespace std;

int main(){
	int dia;
	
	cout << "Digite um numero (0-6) para descobrir o dia da semana: " << endl;
	cin >> dia;
	
	switch(dia){
		case 0:
		cout << "Domingo.";
		break;
		
		case 1:
		cout << "Segunda.";
		break;
		
		case 2:
		cout << "Terca.";
		break;
		
		case 3:
		cout << "Quarta.";
		break;
		
		case 4:
		cout << "Quinta.";
		break;
		
		case 5:
		cout << "Sexta.";
		break;
			
		case 6:
		cout << "Sabado.";
		break;
		
		default: 
		cout << "Numero invalido!";
		break;	
	}
	return 0;
}

#include <iostream>

using namespace std;

class Payment{
	public:
		virtual void processPayment() = 0;		
};

class BitcoinPayment : public Payment{
	public:
	
		void processPayment() override{
		cout << "Voc� realizou o pagamento por BitcoinPayment. " << endl;
		}
};
	
class CreditCardPayment : public Payment{
	public:
		
		void processPayment() override{
		cout << "Voc� realizou o pagamento por CreditCardPayment. " << endl;
		}
};

class PaypalPayment : public Payment{
	public:

		void processPayment() override{
		cout << "Voc� realizou o pagamento por PaypalPayment." << endl;
		}
};
	
int main (){
	BitcoinPayment meuBit;
	meuBit.processPayment();
	
	CreditCardPayment meuCredit;
	meuCredit.processPayment();
	
	PaypalPayment meuPay;
	meuPay.processPayment();
	
	return 0;
}

#include <iostream>

using namespace std;

class Shape{
	public:
		virtual void calcular_area() = 0;		
};

class Circulo : public Shape{
	public:
		float pi_ = 3.1416;
		float raio_ = 10;
		
		void calcular_area() override{
		cout << "A �rea do circulo �: " << pi_ * raio_ * raio_ << endl;
		}
};
	
class Retangulo : public Shape{
	public:
		float base_;
		float altura_ = 2;
		
		Retangulo(float base):
			base_(base)	{}
		
		void calcular_area() override{
		cout << "A �rea do retangulo �: " << base_ * altura_ << endl;
		}
};

class Triangulo : public Shape{
	public:
		float base_ = 10;
		float altura_ = 2;
		
		void calcular_area() override{
		cout << "A �rea do triangulo �: " << (base_ * altura_)/2 << endl;
		}
};
	
int main (){
	Circulo meuCirculo;
	meuCirculo.calcular_area();
	
	Retangulo meuRetangulo(10);
	meuRetangulo.calcular_area();
	
	Triangulo meuTriangulo ;
	meuTriangulo.calcular_area();
	
	return 0;
}

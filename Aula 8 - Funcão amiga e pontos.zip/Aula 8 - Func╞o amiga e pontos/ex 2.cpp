#include <iostream>

using namespace std;

class Retangulo{
	private:
		float altura, largura;
		
	public:
		Retangulo(float altura_, float largura_);
		Retangulo();
		
		friend float calcularPerimetro(Retangulo r);
		friend float calcularArea(Retangulo r);
};

int main(){
	Retangulo meuRetangulo(2.4, 3);
	
	cout << "Area: " << calcularArea(meuRetangulo) << endl;
	cout << "Perimetro: " << calcularPerimetro(meuRetangulo) << endl;
	
	return 0;
}
	
Retangulo :: Retangulo (float altura_, float largura_){
	altura = altura_;
	largura = largura_;
}	

Retangulo :: Retangulo(){}

float calcularPerimetro(Retangulo r){
	return (r.altura * 2) + (r.largura * 2);
}

float calcularArea(Retangulo r){
	return r.altura * r.largura ;
}

#include <iostream>

using namespace std;

class Complexo{
	private:
		float real, imaginario;
	
	public:
		Complexo(float real_, float imaginario_);
		Complexo();
		
		Complexo operator+(Complexo p);
		
		void getComplexo();
		
};

int main(){
	Complexo c1(1,2);
	Complexo c2(2,3);
	Complexo c3 = c2 + c1;
	
	c3.getComplexo();
	
	return 0;
}

Complexo Complexo::operator+(Complexo p){
	real = real+p.real;
	imaginario = imaginario +p.imaginario;
	
	return Complexo(real, imaginario);
}

Complexo :: Complexo(float real_, float imaginario_){
	real = real_;
	imaginario = imaginario_;
}

Complexo :: Complexo(){}

void Complexo :: getComplexo(){
	cout << "(" << real << ", " << imaginario << "i)" << endl;
}



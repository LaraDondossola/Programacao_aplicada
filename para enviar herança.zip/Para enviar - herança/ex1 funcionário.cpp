#include <iostream>

using namespace std;

class Funcionario{
	public:
		float salarioBase_;
		string nome_;
	
		Funcionario(float salarioBase, string nome):
			salarioBase_(salarioBase), nome_(nome){}
		
		virtual void calcularSalarioFinal(){}		
};

class FuncionarioComissionado : public Funcionario{
	public:
		FuncionarioComissionado(float salarioBase, string nome):
			Funcionario(salarioBase, nome){}
			
		void calcularSalarioFinal() override{
			cout << "Nome: " << nome_ << ", Salario: " << salarioBase_ + 500 << endl;
		}
};

class FuncionarioHorista : public Funcionario{
	public:
		FuncionarioHorista(float salarioBase, string nome):
			Funcionario(salarioBase, nome){}
			
		void calcularSalarioFinal() override{
			cout << "Nome: " << nome_ << ", Salario: " << salarioBase_ * 40 << endl;
		}
};


int main(){
	FuncionarioComissionado f1(5000, "Lara");
	FuncionarioHorista f2(50,"Ana");
	
	f1.calcularSalarioFinal();
	f2.calcularSalarioFinal();
	
	return 0;
}



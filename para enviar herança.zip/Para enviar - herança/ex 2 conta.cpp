#include <iostream>

using namespace std;

class Conta{
	public:
		float saldo_;
		string nome_;
	
		Conta(float saldo, string nome):
			saldo_(saldo), nome_(nome){}
		
		virtual void depositar(){}
		
		virtual void sacar(){}		
};

class ContaCorrente : public Conta{
	public:
		float depositar_ = 1000;
		float sacar_ = 100;
		float taxa_ = 10;
		
		ContaCorrente(float saldo, string nome):
			Conta(saldo, nome){}
			
		void depositar() override{
			cout << "Saldo da Conta Corrente apos deposito: " << saldo_ + depositar_ << endl;
		}
		
		void sacar() override{
			cout << "Saldo da Conta Corrente apos saque: " << saldo_ - sacar_ - taxa_ << endl;
		}
};

class ContaPoupanca : public Conta{
	public:
		float depositar_ = 2000;
		float sacar_ = 200;

		ContaPoupanca(float saldo, string nome):
			Conta(saldo, nome){}
			
		void depositar() override{
			cout << "Saldo da Conta Poupanca apos deposito: " << saldo_ + depositar_ << endl;
		}
		
		void sacar() override{
			cout << "Saldo da Conta Poupanca apos saque: " << saldo_ - sacar_ << endl;
		}
};


int main(){
	ContaCorrente c1(5000, "Lara");
	ContaCorrente c2(10000,"Ana");
	
	c1.depositar();
	c2.depositar();
	
	c1.sacar();
	c2.sacar();
	
	return 0;
}

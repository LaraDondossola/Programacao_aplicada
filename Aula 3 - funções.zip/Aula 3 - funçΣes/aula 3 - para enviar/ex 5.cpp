#include <iostream>

using namespace std;

void sacar(float sac);
bool validar(float sac);
float saldo = 3000;
float lim = 1000;
int main(){
	setlocale (LC_ALL, "portuguese");
	float sac;
	
	cout << "Digite o valor que deseja sacar: " << endl;
	cin >> sac;
	sacar(sac);
	
	return 0;
}

void sacar (float sac){
	if (validar(sac)){
			saldo = saldo - sac;
	cout << "saldo atual �: R$ " << saldo;
	}
	else{
		cout << "Saldo insuficinte.";
	}

}

bool validar(float sac){
		return sac <= saldo + lim;
	}

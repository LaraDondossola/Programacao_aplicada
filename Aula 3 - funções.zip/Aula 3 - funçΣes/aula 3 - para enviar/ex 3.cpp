#include <iostream>

using namespace std;

bool ver(int x, int y, int z);

int main(){
	setlocale (LC_ALL, "portuguese");
	int a, b,c;
	
	cout << "Digite o primeiro n�mero: " << endl;
	cin >> a;
	cout << "Digite o segundo n�mero: " << endl;
	cin >> b;
	cout << "Digite o terceiro n�mero: " << endl;
	cin >> c;
	
	bool ordem = ver(a,b,c);
	cout << "1 para ordenado em crescente, e 0 caso contr�rio : " << ordem;
	
	return 0;
}
	
	
	bool ver (int x, int y, int z ){
		return x <= y && y <= z;
	}


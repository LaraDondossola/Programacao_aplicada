#include <iostream>

using namespace std;

void sacar(float sac);
float saldo = 3000;

int main(){
	setlocale (LC_ALL, "portuguese");
	float sac;
	
	cout << "Digite o valor que deseja sacar: " << endl;
	cin >> sac;
	sacar(sac);
	
	return 0;
}

void sacar (float sac){
	saldo = saldo - sac;
	cout << "saldo atual �: R$ " << saldo;
}
	


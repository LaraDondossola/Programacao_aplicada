#include <iostream>

using namespace std;

char verificacao (int a);

int main(){
	
	setlocale (LC_ALL, "portuguese");
	
	int n1;
	
	cout << "Digite um numero inteiro: " << endl;
	cin >> n1;
	cout << "O numero � (P: positivo, N: igual ou menor que zero): " << verificacao(n1);
	return 0;
}

char verificacao (int a){
	if (a > 0){
		return 'P';
}
	else{
		return 'N';
	}
		
		
}

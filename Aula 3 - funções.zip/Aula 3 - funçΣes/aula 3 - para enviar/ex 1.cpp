#include <iostream>

using namespace std;

int soma(int x, int y, int z);

int main(){
	int a, b,c;
	
	cout << "Digite o primeiro numero: " << endl;
	cin >> a;
	cout << "Digite o segundo numero: " << endl;
	cin >> b;
	cout << "Digite o terceiro numero: " << endl;
	cin >> c;
	
	int resultado = soma(a,b,c);
	cout << "O resultado da soma desses numeros e: " << resultado;
	
	return 0;
}
	
	
	int soma (int x, int y, int z ){
		return x+y+z;
	}


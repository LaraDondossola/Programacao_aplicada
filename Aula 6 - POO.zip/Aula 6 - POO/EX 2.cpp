#include <iostream>

using namespace std;

class Retangulo {
private:
	int largura;
	int altura;

public:
	Retangulo (int lar, int alt){
		largura = lar;
		altura = alt;
	}
	
	void exibirInfo(){
		cout << "Largura: " << largura << endl;
		cout << "Altura: " << altura << endl;
	}
	
	void calcular_area(){
		cout << "A �rea �: " << largura * altura << endl;
	}
	
	void calcular_perimetro(){
		cout << "O perimetro �: " << (largura*2) + (altura*2) << endl;
	}
	
	void setLargura(int larg){
		largura = larg;
	}
	
	void setAltura(int alt){
		altura = alt;
	}
	
	int getLargura(){
		return largura;
	}
	
	int getAltura(){
		return altura;
	}
	
};

int main (){
    int largura, altura;
	
	cout << "Digite a largura do ret�ngulo em cm: " << endl;
	cin >> largura;
	cout << "Digite a altura do ret�ngulo em cm: " << endl;
	cin >> altura;
	
	Retangulo meuRetangulo (largura, altura);
	meuRetangulo.exibirInfo();
	meuRetangulo.calcular_area();
	meuRetangulo.calcular_perimetro();
	
	return 0;
}


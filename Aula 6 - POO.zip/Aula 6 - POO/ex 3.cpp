#include <iostream>

using namespace std;

class ContaBancaria {
private:
	double saldo = 0;
	string senha = "1234";
	string titular;

public:
	ContaBancaria (string tit){
		titular = tit;
	}
	
	void depositar(int valor){
		saldo += valor;
	}
	
	void sacar(int valor, string sen){
		if ((saldo >= valor) && (senha == sen)){
			saldo -= valor;
		}
		else{
			cout << "Senha ou valor incompat�vel.";
		}
	}
	
	void setDepositar(int valor, string sen){
		if (senha == sen){
			cout << "O saldo �: " << saldo;
		}
	}
	
	float getSaldo() {
		return saldo;
	}
};

int main (){
	string senha, titular;
    double saldo, valor;
    
    ContaBancaria minhaConta ("Lara");
	minhaConta.depositar(100);
	cout << "Saldo atual: R$ " << minhaConta.getSaldo() << endl;
	minhaConta.sacar (50,"12345");
	cout << "Saldo atual: R$ " << minhaConta.getSaldo() << endl;
	
	
	return 0;
}


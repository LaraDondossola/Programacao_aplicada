#include <iostream>

using namespace std;

class CidadesBrasil {
private:
	string nome;
	string data;
	int numero_habitantes;
	int numero_eleitores;

public:
	CidadesBrasil (string n, string dat, int hab, int elei){
		nome = n;
		data = dat;
		numero_habitantes = hab;
		numero_eleitores = elei;
	}
	
	void exibirInfo(){
		cout << "Nome: " << nome << endl;
		cout << "Data: " << data << endl;
		cout << "N�mero de Habitantes: " <<  numero_habitantes << endl;
		cout << "N�mero de Eleitores: " <<  numero_eleitores << endl;
	}
	
};

int main (){
	string nome, data;
    int numero_habitantes, numero_eleitores;
	
	cout << "Digite o nome da cidade: " << endl;
	cin >> nome;
	cout << "Digite a data de funda��o: " << endl;
	cin >> data;
	cout << "Digite o n�mero de habitantes: " << endl;
	cin >> numero_habitantes;
	cout << "Digite o n�mero de eleitores: " << endl;
	cin >> numero_eleitores;
	
	CidadesBrasil minhaCidade (nome, data, numero_habitantes, numero_eleitores);
	minhaCidade.exibirInfo();
	
	return 0;
}



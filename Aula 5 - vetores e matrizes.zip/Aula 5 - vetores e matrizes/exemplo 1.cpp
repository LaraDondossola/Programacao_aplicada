#include <iostream>

using namespace std;

int main (){
	int numeros[5];
	int soma = 0;
	
	
	for (int i = 0; i < 5; ++i){
		cout << "Digite 5 n�meros inteiros: " << endl;
		cin >> numeros[i];
	}
	
	for (int i = 0; i < 5; ++i) {
		soma += numeros[i];
	}
	
	cout << "A soma do vetor �: " << soma;
	
	return 0;
}

#include <iostream>

using namespace std;

int main (){
	int numeros[10];
	int soma = 0;
	
	cout << "Digite 10 n�meros inteiros: " << endl;
	for (int i = 0; i < 10; ++i){
		cin >> numeros[i];
	}
	
	int maiorNumero = numeros[0];
	
	for (int i = 0; i < 10; ++i ){
		if (maiorNumero < numeros[i]){
			maiorNumero = numeros[i];
		}
	}
	
	
	cout << "O maior numero e: " << maiorNumero;
	
	return 0;
}

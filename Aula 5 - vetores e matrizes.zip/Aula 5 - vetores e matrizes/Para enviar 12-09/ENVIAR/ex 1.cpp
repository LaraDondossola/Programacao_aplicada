#include <iostream>

using namespace std;

int main (){
	int A [6]  = {1,0,5,-2,-5,7};
	int soma;
	
	soma = A[0] + A[1] + A[5];
	
	cout << "A soma e: " << soma << endl;
	
	A[4] = 100;
	
	for (int i = 0; i < 6; ++i){
		cout << i << " - " << A[i] << endl;
	}
	
	return 0;	
}

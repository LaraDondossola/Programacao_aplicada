#include <iostream>

using namespace std;

int main(){
	int matriz [3][3];
	int soma [3] = {0,0,0};
	
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			cout << "Digite o valor da matriz: " << endl;
			cin >> matriz[i][j];
	}
}
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			cout << matriz[i][j]<< " ";
	}
	cout << endl;
	}
	
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			soma [j] += matriz[i][j];
	}
}
	cout << endl;
	
	for (int i = 0; i < 3; ++i){
		cout << soma[i] << " ";
	}
	return 0;
}

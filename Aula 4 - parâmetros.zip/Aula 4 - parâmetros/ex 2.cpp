#include <iostream>

using namespace std;

int calcular(int a, int b, char c){
	switch (c){
		case '+':
			return a+b;
			break;
		
		case '-':
			return a-b;
			break;
		
		case '*':
			return a*b;
			break;
			
		case '/':
			return a/b;
			break;
		
			
		default:
			cout << "Operador nao encontrado." << endl;
			break;
	}
	
}
int main(){
	int n1, n2;
	char n3;
	
	cout << "Digite o primeiro numero: " << endl;
	cin >> n1;
	cout << "Digite o segundo numero: " << endl;
	cin >> n2;
	cout << "Digite operador(+,-,*,/)" << endl;
	cin >> n3;
	
	int resultado = calcular (n1,n2,n3);
	cout << resultado;
	return 0;
}

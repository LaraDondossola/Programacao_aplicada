#include <iostream>

using namespace std;

int trocar(int &a, int &b){
	int temp = a;
    a = b;
    b = temp;		
}

int main(){
	int n1, n2;
	
	cout << "Digite o primeiro numero inteiro: " << endl;
	cin >> n1;
	cout << "Digite o segundo numero inteiro: " << endl;
	cin >> n2;
	
	cout << "Antes da troca: " << n1 << ", "  << n2 << endl;
	trocar(n1,n2);
	cout << "Depois da troca: " << n1 << ", "  << n2 << endl;
	return 0;
}

#include <iostream>

using namespace std;

void calcular (int a, int b ,int c){
	cout << "A area do triangulo em cm: " << (a*b) / c;
}

void calcular (float a,int b){
	cout << "A area do circulo em cm: " << a * b * b;
}

void calcular (int a,int b ){
	cout << "A area do retangulo em cm: " << a * b;
}

int main(){
	float pi, raio;
	int forma, base, altura;
	pi = 3,1416;
	
	cout << "Digite o codigo da forma geometrica que deseja calcular a �rea (1 triangulo, 2 circulo, 3 retangulo): " << endl;
	cin >> forma;
	
	if (forma == 2){
		cout << "Digite o raio do circulo em cm: " << endl;
		cin >> raio;
	}
	else{
	cout << "Digite o valor da base em cm: " << endl;
	cin >> base;
	cout << "Digite o valoor da altura em cm: " << endl;
	cin >> altura;
}
	
	switch (forma){
		case 1:
			calcular (base, altura, 2);
			break;
		
		case 2:
			calcular (pi, raio);
			break;
			
		case 3:
			calcular(base, altura);
			break;
			
		default:
			cout << "Nao encontrado" ;
	}
	
	return 0;
}

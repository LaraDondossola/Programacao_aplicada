#include <iostream>
#include <string>

using namespace std;

int main(){
	int idade;
	string nome;
	
	cout <<"Digite seu nome: ";
	cin >> nome;
	cout <<"Digite sua idade: ";
	cin >> idade;
	
	cout << "Ol�, " << nome << "! Voc� tem " << idade << " anos.";
	return 0;
}

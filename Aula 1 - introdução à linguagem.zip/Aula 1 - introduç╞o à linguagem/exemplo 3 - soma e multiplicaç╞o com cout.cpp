#include <iostream>

int main(){
	int a = 5; //a recebe 5 que � um n�mero inteiro
	double b = 3.14;//b recebe 3.14 que � uma variavel do float
	char c = 'A';//c recebe A que � uma CARACTERE, que utiliza aspas simples
	
	int soma = a +2;
	double area = b*a;
	
	std::cout<< "SOMA: " << soma << std::endl;
	std::cout<< "AREA: " << area << std::endl;
	std::cout<<"CARACTERE: "<<c << std::endl;
	return 0;
}

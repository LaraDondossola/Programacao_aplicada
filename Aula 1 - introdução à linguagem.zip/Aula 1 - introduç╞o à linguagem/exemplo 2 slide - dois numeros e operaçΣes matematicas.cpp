#include <iostream>

using namespace std;

int main (){
	float num1, num2;
	
	cout << "Digite um n�mero: " << std::endl;
	cin >> num1;
	cout << "Digite outro n�mero: " << std::endl;
	cin >> num2;
	
	cout << "SOMA: " << num1 + num2 << endl;
	cout << "SUBTRA��O: " << num1 - num2 << endl;
	cout << "MULTIPLICA��O: " << num1 * num2 << endl;
	cout << "DIVIS�O: " << num1 / num2 << endl;
	return 0;
}

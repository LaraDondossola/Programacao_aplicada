#include <iostream>

using namespace std;

int main (){
	float temp;
	float far;
	
	cout << "Digite a temperatura em graus Celsius: " << endl;
	cin >> temp;
	
	far = temp*9 / 5 +32;
	
	cout << "A temperatura em Fahrenheit e: " << far;
		
	
	return 0;
}

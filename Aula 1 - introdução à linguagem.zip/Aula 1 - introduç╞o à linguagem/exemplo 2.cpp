#include<iostream>

using namespace std;//usado para n�o colocar std na frente de todas as entradas e sa�das 

int main(){
	int num;//variavel para solicitar o numero
	cout <<"Exemplo 2:"<<endl;// endl � para pular uma linha 
	cout << "Digite um numero: "; //entrada de dados 
	cin>> num; //usado para entrada de dados, o cin t� atribuindo o cout ao n�mero
	cout << "O n�mero digitado foi: " << num;
	
	return 0;
}

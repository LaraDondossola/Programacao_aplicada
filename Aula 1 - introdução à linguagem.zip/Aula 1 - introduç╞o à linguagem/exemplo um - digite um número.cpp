#include<iostream>

int main(){
	int num;//variavel para solicitar o numero
	std::cout << "Digite um numero: "; //entrada de dados 
	std::cin>> num; //usado para entrada de dados, o cin t� atribuindo o cout ao n�mero
	std::cout << "O n�mero digitado foi: " << num;
	
	return 0;
}
